package com.example.customtitlescreen.client.auth;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.function.Consumer;

/**
 * Standalone Microsoft "device code" login flow, exactly the mechanism used
 * by third-party launchers (Prism Launcher, MultiMC and similar) that let you
 * add a Microsoft/Minecraft account without embedding a web browser.
 *
 * You MUST supply your own Azure AD application client id (free, from
 * portal.azure.com -> App registrations -> New registration -> set as a
 * "public client", then add API permission "XboxLive.signin offline_access").
 * Using someone else's client id without permission breaks Microsoft's terms.
 *
 * This was written against the publicly documented endpoints and has not
 * been compiled/run in a live environment — if a JSON field name below turns
 * out to differ, the fix is a one-line key rename in the matching method.
 */
public final class MicrosoftAuth {

    /** Replace with your own Azure AD "Application (client) ID". */
    public static final String CLIENT_ID = "PUT-YOUR-AZURE-APP-CLIENT-ID-HERE";

    private static final String SCOPE = "XboxLive.signin offline_access";
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    public record DeviceCodeInfo(String deviceCode, String userCode, String verificationUri,
                                  int intervalSeconds, int expiresInSeconds) {}

    public record MinecraftAccount(String username, String uuid, String minecraftAccessToken) {}

    public static class AuthException extends RuntimeException {
        public AuthException(String message) { super(message); }
    }

    /** Step 1: ask Microsoft for a device code + short code the user types in a browser. */
    public static DeviceCodeInfo requestDeviceCode() {
        String body = "client_id=" + CLIENT_ID + "&scope=" + urlEncode(SCOPE);
        JsonObject json = postForm("https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode", body);
        return new DeviceCodeInfo(
                json.get("device_code").getAsString(),
                json.get("user_code").getAsString(),
                json.get("verification_uri").getAsString(),
                json.has("interval") ? json.get("interval").getAsInt() : 5,
                json.has("expires_in") ? json.get("expires_in").getAsInt() : 900
        );
    }

    /**
     * Step 2: poll until the user finishes signing in on their phone/PC browser.
     * Blocking — call this from a background thread, never the render thread.
     * onStatus receives human-readable progress updates you can show in the UI.
     */
    public static MinecraftAccount pollAndLogin(DeviceCodeInfo device, Consumer<String> onStatus) {
        String msAccessToken = pollDeviceToken(device, onStatus);

        onStatus.accept("Входим через Xbox Live...");
        JsonObject xbl = authenticateXboxLive(msAccessToken);
        String xblToken = xbl.get("Token").getAsString();
        String userHash = xbl.getAsJsonObject("DisplayClaims")
                .getAsJsonArray("xui").get(0).getAsJsonObject()
                .get("uhs").getAsString();

        onStatus.accept("Получаем XSTS-токен...");
        String xstsToken = authenticateXSTS(xblToken);

        onStatus.accept("Входим в Minecraft...");
        String mcAccessToken = loginWithXbox(userHash, xstsToken);

        onStatus.accept("Загружаем профиль...");
        JsonObject profile = fetchProfile(mcAccessToken);
        String username = profile.get("name").getAsString();
        String uuid = profile.get("id").getAsString();

        onStatus.accept("Готово!");
        return new MinecraftAccount(username, uuid, mcAccessToken);
    }

    // ---------------------------------------------------------- steps

    private static String pollDeviceToken(DeviceCodeInfo device, Consumer<String> onStatus) {
        long deadline = System.currentTimeMillis() + device.expiresInSeconds() * 1000L;
        int intervalMs = Math.max(2, device.intervalSeconds()) * 1000;

        onStatus.accept("Открой " + device.verificationUri() + " и введи код: " + device.userCode());

        while (System.currentTimeMillis() < deadline) {
            sleep(intervalMs);
            String body = "grant_type=urn:ietf:params:oauth:grant-type:device_code"
                    + "&client_id=" + CLIENT_ID
                    + "&device_code=" + device.deviceCode();
            HttpResponse<String> resp = postFormRaw("https://login.microsoftonline.com/consumers/oauth2/v2.0/token", body);
            JsonObject json = JsonParser.parseString(resp.body()).getAsJsonObject();

            if (resp.statusCode() == 200 && json.has("access_token")) {
                return json.get("access_token").getAsString();
            }
            String error = json.has("error") ? json.get("error").getAsString() : "unknown_error";
            switch (error) {
                case "authorization_pending" -> onStatus.accept("Ждём подтверждения в браузере...");
                case "slow_down" -> intervalMs += 2000;
                case "expired_token" -> throw new AuthException("Код истёк, попробуй снова.");
                case "authorization_declined" -> throw new AuthException("Вход отклонён.");
                default -> throw new AuthException("Ошибка Microsoft: " + error);
            }
        }
        throw new AuthException("Время ожидания входа истекло.");
    }

    private static JsonObject authenticateXboxLive(String msAccessToken) {
        JsonObject payload = new JsonObject();
        JsonObject properties = new JsonObject();
        properties.addProperty("AuthMethod", "RPS");
        properties.addProperty("SiteName", "user.auth.xboxlive.com");
        properties.addProperty("RpsTicket", "d=" + msAccessToken);
        payload.add("Properties", properties);
        payload.addProperty("RelyingParty", "http://auth.xboxlive.com");
        payload.addProperty("TokenType", "JWT");

        return postJson("https://user.auth.xboxlive.com/user/authenticate", payload.toString());
    }

    private static String authenticateXSTS(String xblToken) {
        JsonObject payload = new JsonObject();
        JsonObject properties = new JsonObject();
        properties.addProperty("SandboxId", "RETAIL");
        com.google.gson.JsonArray userTokens = new com.google.gson.JsonArray();
        userTokens.add(xblToken);
        properties.add("UserTokens", userTokens);
        payload.add("Properties", properties);
        payload.addProperty("RelyingParty", "rp://api.minecraftservices.com/");
        payload.addProperty("TokenType", "JWT");

        JsonObject json = postJson("https://xsts.auth.xboxlive.com/xsts/authorize", payload.toString());
        return json.get("Token").getAsString();
    }

    private static String loginWithXbox(String userHash, String xstsToken) {
        JsonObject payload = new JsonObject();
        payload.addProperty("identityToken", "XBL3.0 x=" + userHash + ";" + xstsToken);
        JsonObject json = postJson("https://api.minecraftservices.com/authentication/login_with_xbox", payload.toString());
        return json.get("access_token").getAsString();
    }

    private static JsonObject fetchProfile(String mcAccessToken) {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://api.minecraftservices.com/minecraft/profile"))
                .header("Authorization", "Bearer " + mcAccessToken)
                .GET()
                .build();
        return send(request);
    }

    // ---------------------------------------------------------- http helpers

    private static JsonObject postForm(String url, String body) {
        return JsonParser.parseString(postFormRaw(url, body).body()).getAsJsonObject();
    }

    private static HttpResponse<String> postFormRaw(String url, String body) {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();
        try {
            return HTTP.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (Exception e) {
            throw new AuthException("Сеть недоступна: " + e.getMessage());
        }
    }

    private static JsonObject postJson(String url, String body) {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();
        return send(request);
    }

    private static JsonObject send(HttpRequest request) {
        try {
            HttpResponse<String> resp = HTTP.send(request, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() / 100 != 2) {
                throw new AuthException("HTTP " + resp.statusCode() + ": " + resp.body());
            }
            return JsonParser.parseString(resp.body()).getAsJsonObject();
        } catch (AuthException e) {
            throw e;
        } catch (Exception e) {
            throw new AuthException("Сеть недоступна: " + e.getMessage());
        }
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new AuthException("Прервано");
        }
    }

    private static String urlEncode(String s) {
        return java.net.URLEncoder.encode(s, java.nio.charset.StandardCharsets.UTF_8);
    }

    private MicrosoftAuth() {}
}
