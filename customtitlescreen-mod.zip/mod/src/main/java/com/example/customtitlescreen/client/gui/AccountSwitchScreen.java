package com.example.customtitlescreen.client.gui;

import com.example.customtitlescreen.client.auth.MicrosoftAuth;
import com.example.customtitlescreen.mixin.MinecraftClientSessionAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.session.Session;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.net.URI;
import java.util.concurrent.atomic.AtomicReference;

public class AccountSwitchScreen extends Screen {

    private final Screen parent;
    private final AtomicReference<String> status = new AtomicReference<>("Нажми, чтобы войти через Microsoft.");
    private volatile MicrosoftAuth.DeviceCodeInfo deviceInfo = null;
    private volatile boolean loginInProgress = false;
    private volatile boolean done = false;

    private ButtonWidget loginButton;
    private ButtonWidget openBrowserButton;

    public AccountSwitchScreen(Screen parent) {
        super(Text.literal("Сменить аккаунт"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int cy = this.height / 2;

        loginButton = ButtonWidget.builder(Text.literal("Войти через Microsoft"), btn -> startLogin())
                .dimensions(cx - 100, cy - 10, 200, 20)
                .build();
        addDrawableChild(loginButton);

        openBrowserButton = ButtonWidget.builder(Text.literal("Открыть страницу входа"), btn -> {
            if (deviceInfo != null && this.client != null) {
                Util.getOperatingSystem().open(URI.create(deviceInfo.verificationUri()));
            }
        }).dimensions(cx - 100, cy + 16, 200, 20).build();
        openBrowserButton.visible = false;
        addDrawableChild(openBrowserButton);

        addDrawableChild(ButtonWidget.builder(Text.literal("Назад"), btn -> {
            if (this.client != null) this.client.setScreen(parent);
        }).dimensions(cx - 100, cy + 44, 200, 20).build());
    }

    private void startLogin() {
        if (loginInProgress) return;
        loginInProgress = true;
        loginButton.active = false;

        Thread thread = new Thread(() -> {
            try {
                MicrosoftAuth.DeviceCodeInfo device = MicrosoftAuth.requestDeviceCode();
                deviceInfo = device;
                openBrowserButton.visible = true;
                status.set("Код: " + device.userCode() + "  —  открой браузер и введи его.");

                MicrosoftAuth.MinecraftAccount account = MicrosoftAuth.pollAndLogin(device, status::set);

                if (this.client != null) {
                    this.client.execute(() -> applyAccount(account));
                }
            } catch (MicrosoftAuth.AuthException e) {
                status.set("Ошибка: " + e.getMessage());
            } catch (Exception e) {
                status.set("Непредвиденная ошибка: " + e);
            } finally {
                loginInProgress = false;
            }
        }, "customtitlescreen-ms-login");
        thread.setDaemon(true);
        thread.start();
    }

    /** Runs on the render thread. Swaps the active session and returns to the main menu. */
    private void applyAccount(MicrosoftAuth.MinecraftAccount account) {
        MinecraftClient client = this.client;
        if (client == null) return;

        // See MinecraftClientSessionAccessor's javadoc if this constructor
        // doesn't match your mappings' Session class.
        Session newSession = new Session(
                account.username(),
                account.uuid(),
                account.minecraftAccessToken(),
                java.util.Optional.empty(),
                java.util.Optional.empty(),
                Session.AccountType.MSA
        );
        ((MinecraftClientSessionAccessor) client).customtitlescreen$setSession(newSession);

        done = true;
        status.set("Готово! Вошли как " + account.username());
        client.setScreen(parent);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        super.render(context, mouseX, mouseY, delta);

        context.drawCenteredTextWithShadow(this.textRenderer, this.getTitle(), this.width / 2, this.height / 2 - 60, 0xFFFFFF);

        String s = status.get();
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(s), this.width / 2, this.height / 2 - 40, 0xC8C8C8);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
